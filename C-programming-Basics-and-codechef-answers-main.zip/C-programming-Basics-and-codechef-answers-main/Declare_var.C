#include<stdio.h>
int main(){
  
  int a = 12;
  printf("%d",a);
  return 0;
}

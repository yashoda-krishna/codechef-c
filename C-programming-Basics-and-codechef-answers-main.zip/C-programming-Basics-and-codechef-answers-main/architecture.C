#include <stdio.h>
int main(){
  
//.......statements......//
  
  printf("Hello world");
  return 0; 
}
